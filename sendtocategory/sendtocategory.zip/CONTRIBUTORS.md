## Creator
* John Bieling

## Translators
 * John Bieling (de, en-US)
 * Pierrick Brun (fr)
 * Lisandro Gallo (es-AR)
 * Wanderlei Hüttel (pt-BR)
 * Alexey Sinitsyn (ru)
 * Jan Zaunbrecher (nl)
